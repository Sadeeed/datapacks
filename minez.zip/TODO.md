## TODO

# Thirst

+ Use xp bar or boss bar
+ Decrese 1 point after n time (takes 15 mins to fully deplete)
+ Damage when low
+ Fully replenish with a water bottle
+ Notify when dehydrated


# Infection

+ 2.5% chance when hit by a zombie
+ 0.5 Damage every 15 seconds
+ Invisible (Barely Visible) Particles 
+ Nausea every 15-20 secs
+ Notify When Infected

